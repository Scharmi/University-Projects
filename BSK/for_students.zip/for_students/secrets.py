FLAG1 = 'flag{not-a-real-flag!!!}'
FLAG2 = 'flag{not-real!!}'
FLAG3 = 'flag{this-is-still-not-the-real-flag-exploit-the-server..}'
